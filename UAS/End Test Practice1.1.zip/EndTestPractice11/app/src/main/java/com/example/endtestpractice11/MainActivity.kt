package com.example.endtestpractice11

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.cardview.widget.CardView
import com.example.endtestpractice11.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity(), View.OnClickListener {
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)

        val btnmakanan: CardView = findViewById(R.id.btn_makanan)
        btnmakanan.setOnClickListener(this)
        val btnrumah: CardView = findViewById(R.id.btn_rumah)
        btnrumah.setOnClickListener(this)
        val btnibu: CardView = findViewById(R.id.btn_Ibu)
        btnibu.setOnClickListener(this)
        val btnkesehatan: CardView = findViewById(R.id.btn_kesehatan)
        btnkesehatan.setOnClickListener(this)


    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return super.onSupportNavigateUp()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.option_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.menu1 -> {
                val i = Intent(this, MakananActivity::class.java)
                startActivity(i)
                return true
            }
            R.id.menu2 -> {
                val i = Intent(this, RumahActivity::class.java)
                startActivity(i)
                return true
            }
            R.id.menu3 -> {
                val i = Intent(this, IbuActivity::class.java)
                startActivity(i)
                return true
            }
            R.id.menu4 -> {
                val i = Intent(this, KesehatanActivity::class.java)
                startActivity(i)
                return true
            }
            else -> return true
        }
    }


    override fun onClick(v: View) {
        when (v.id) {
            R.id.btn_makanan -> {
                val moveActivity = Intent(this, MakananActivity::class.java)
                startActivity(moveActivity)
            }
            R.id.btn_rumah -> {
                val moveActivity = Intent(this, RumahActivity::class.java)
                startActivity(moveActivity)
            }
            R.id.btn_Ibu -> {
                val moveActivity = Intent(this, IbuActivity::class.java)
                startActivity(moveActivity)
            }
            R.id.btn_kesehatan -> {
                val moveActivity = Intent(this, KesehatanActivity::class.java)
                startActivity(moveActivity)
            }
        }
    }
}